# Pineapple Website 🍍

Simple pineapple-themed website project.

## Features
- Bright tropical UI
- Simple JavaScript interaction
- Clean layout

## How to Run
Open `index.html` in your browser.

## Author
Your Name
