function showMessage() {
    alert("Pineapple is delicious! 🍍");
}
